var searchData=
[
  ['save_36',['Save',['../classImage.html#adde1007dc6359087dae65fa8cae26448',1,'Image']]],
  ['set_5fpixel_37',['set_pixel',['../classImage.html#a6e316f867fd3b67a75d78ca66bc12195',1,'Image::set_pixel(int i, int j, byte value)'],['../classImage.html#adf54cab55e991b8fac7d8043507588cb',1,'Image::set_pixel(int k, byte value)']]],
  ['shufflerows_38',['ShuffleRows',['../classImage.html#a11a345fdbc0dc923a95d6a47884200f1',1,'Image']]],
  ['size_39',['size',['../classImage.html#a78068ea10fef9954ea0e91705997652d',1,'Image']]],
  ['subimagen_2ecpp_40',['subimagen.cpp',['../subimagen_8cpp.html',1,'']]],
  ['subsample_41',['Subsample',['../classImage.html#aa00e596a67ec6130922c560049457985',1,'Image']]]
];
