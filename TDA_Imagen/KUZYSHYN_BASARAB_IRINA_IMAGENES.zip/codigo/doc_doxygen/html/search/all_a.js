var searchData=
[
  ['negativo_2ecpp_30',['negativo.cpp',['../negativo_8cpp.html',1,'']]]
];
