var searchData=
[
  ['adjustcontrast_59',['AdjustContrast',['../classImage.html#a4884f3eb51efdecc005092534ba7e4ea',1,'Image']]],
  ['allocate_60',['Allocate',['../classImage.html#a4e14fe063d101e883a5b87c28ae65a29',1,'Image']]]
];
