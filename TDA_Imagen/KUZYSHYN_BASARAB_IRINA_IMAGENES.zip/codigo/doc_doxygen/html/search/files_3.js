var searchData=
[
  ['negativo_2ecpp_56',['negativo.cpp',['../negativo_8cpp.html',1,'']]]
];
