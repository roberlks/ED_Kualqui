var searchData=
[
  ['zoom_2ecpp_43',['zoom.cpp',['../zoom_8cpp.html',1,'']]],
  ['zoom2x_44',['Zoom2X',['../classImage.html#af7c220a99f8b90c6e9f243ee22943305',1,'Image']]]
];
